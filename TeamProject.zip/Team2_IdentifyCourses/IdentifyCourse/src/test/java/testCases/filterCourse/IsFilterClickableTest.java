package testCases.filterCourse;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.FilterCourse;
import pages.SearchCourse;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class IsFilterClickableTest extends DriverSetup{

	FilterCourse filterCourse;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;
	
	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		filterCourse = new FilterCourse();
		SearchCourse searchCourse=new SearchCourse();
		filterCourse = searchCourse.clickSearchbox();
	}
	
	//To check language Fliter is clickable
	@Test
	public void languageFilterClickable() {
		
		boolean flag1 = FilterCourse.clickLanguage();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertTrue(flag1);
		System.out.println("Language Fliter is Clickable");

	}
	
	//To check level Fliter is clickable
	@Test
	public void levelFilterClickable() {
		logger = report.createTest("To check level Fliter is clickable");

		boolean flag1 = FilterCourse.clickLevel();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertTrue(flag1);
		System.out.println("Level Fliter is Clickable");
	}
	
	//To check learning Product Fliter is clickable
	@Test
    public void LearningProductFilterClickable() {
		
		boolean flag1 = FilterCourse.clickLearningProduct();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertTrue(flag1);
		System.out.println("Learning Product Fliter is Clickable");

	}
	
	
	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}
	
}

