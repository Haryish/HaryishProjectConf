package testCases.filterCourse;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
//import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
//import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.FilterCourse;
import pages.SearchCourse;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class RelevantDataTest extends DriverSetup {

	FilterCourse filterCourse;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;
	@BeforeMethod
	public void openBrowser() {
		setupBrowser();
		filterCourse = new FilterCourse();
		SearchCourse searchCourse=new SearchCourse();
		filterCourse = searchCourse.clickSearchbox();
	}
	
	//To check language fliter is applied
	@Test
	public void checkingLanguagefilter() {
		String language = null;
	    filterCourse.selectLanguage();
	    String parentWindow = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(FilterCourse.coursename));
		FilterCourse.coursename.click();
		Set<String> handles1 = driver.getWindowHandles();
		Iterator<String> itr1 = handles1.iterator();
		while(itr1.hasNext()) {
			
			String childWindow1 = itr1.next();
			if (!childWindow1.contentEquals(parentWindow)) {
				driver.switchTo().window(childWindow1);
				language=FilterCourse.checklanguage.getText();
			}
			driver.switchTo().window(parentWindow);
	}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertEquals( language, "English");
		//System.out.println("Language Fliter applied");

	}
	
	//To check level fliter is applied
	@Test
	public void checkingLevelFilter() {
		
	    filterCourse.selectLevel();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertEquals( filterCourse.checkbeginner(), "Beginner");
		//System.out.println("Level Fliter applied");

	}
	
	//To check learningProduct fliter is applied
	@Test
	public void checkingLearningProductFilter() {
		logger = report.createTest("To check learningProduct fliter is applied");
	    filterCourse.selectproduct();;
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertEquals( filterCourse.checkcourses(), "Course");
		//System.out.println("Learning Product Fliter applied");

	}
	
	@AfterMethod
	public void tearDown() {
		report.flush();

		driver.quit();
	}
	
}
