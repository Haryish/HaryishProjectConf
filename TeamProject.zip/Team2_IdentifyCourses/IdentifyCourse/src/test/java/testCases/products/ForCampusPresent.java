package testCases.products;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.Enterprise;
import pages.ProductsHome;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class ForCampusPresent extends DriverSetup {


	Enterprise enterprise;
	ProductsHome productshome;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;

	public ForCampusPresent (){
		super();
	}
	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		productshome=new ProductsHome ();
		enterprise = new Enterprise();
		enterprise.navigateToForEnterprise();
		productshome.checkDropdown();
	}

	//Check for ForCampus
	@Test
	public void checkForCampus(){
		logger = report.createTest("Check for ForCampus");
		boolean flag1 = productshome.checkForCampus();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Assert.assertTrue(flag1);
		System.out.println("For Campus is present");


	}

	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}
}


