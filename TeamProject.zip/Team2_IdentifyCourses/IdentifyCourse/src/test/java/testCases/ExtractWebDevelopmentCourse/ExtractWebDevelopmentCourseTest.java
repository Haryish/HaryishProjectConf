package testCases.ExtractWebDevelopmentCourse;


import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.ExtractWebDevelopmentCourses;
import pages.FilterCourse;
import pages.SearchCourse;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class ExtractWebDevelopmentCourseTest extends DriverSetup{

	ExtractWebDevelopmentCourses extractWebCourses;
	protected ExtentReports report=ExtentReportManager.getReportInstance();
	protected ExtentTest logger;
	
	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		FilterCourse filterCourse = new FilterCourse();
		SearchCourse searchCourse=new SearchCourse();
		filterCourse = searchCourse.clickSearchbox();
		filterCourse.selectLanguage();
		filterCourse.selectLevel();
		filterCourse.selectproduct();
		extractWebCourses=filterCourse.selectedfliterCourses();
	}
	
	//finding courses
	@Test
    public void CourseDetails() {
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			extractWebCourses.findCourses();
		System.out.println("Two courses displayed succesfully");
	}
	

	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}
