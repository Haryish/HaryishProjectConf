package testCases.launchBrowser;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class LaunchBrowserTest extends DriverSetup{
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;
	Logger log=Logger.getLogger(LaunchBrowserTest.class);


	public LaunchBrowserTest() {

		super();
	}

	@BeforeClass
	public void openBrowser() {
		setupBrowser();

	}

	//to check correct application is opened
	@Test
	public void courseraApplicationOpened() {
		logger = report.createTest("Extract Movie Languages And Display");
		Assert.assertEquals(driver.getTitle(), "Coursera in India | Online Courses & Certificates From Top Institutions");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		log.info("Title verified");
	}

	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}
}
