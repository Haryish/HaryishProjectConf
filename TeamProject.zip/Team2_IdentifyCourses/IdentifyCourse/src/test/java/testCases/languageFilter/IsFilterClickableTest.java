package testCases.languageFilter;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.languageFilter;
import pages.languagelearningSearch;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class IsFilterClickableTest extends DriverSetup{

	languageFilter LanguageFilter;
	languagelearningSearch LanguagelearningSearch;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;

	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		LanguageFilter = new languageFilter();
		LanguagelearningSearch =new languagelearningSearch();
		LanguageFilter = LanguagelearningSearch.clickSearchbox();
	}
	
	@Test
	public void languageFilterClickable() {
		logger = report.createTest("Language Filter");

		driver.findElement(By.className("Select-arrow-zone")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}
	
	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}
	
}

