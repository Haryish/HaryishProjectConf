package testCases.fillingForm;


import java.util.Iterator;
import java.util.Set;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.Enterprise;
import pages.FillingForm;
import pages.ProductsHome;
import utilities.DriverSetup;
import utilities.ReadExcelfile;

public class FillingFormswithValidDetailsTest extends DriverSetup {

	
	String parentWindow;
	ProductsHome productsHome;
	FillingForm fillingForm;

	String sheetName1 = "FirstPage";

	public FillingFormswithValidDetailsTest() {
		super();
	}

	@BeforeClass
	public void setUp() {

		setupBrowser();
		Enterprise enterprise=new Enterprise();
		productsHome=enterprise.navigateToForEnterprise();
		fillingForm=productsHome.navigateToFillingForm();
		
	}

	@DataProvider
	public Object[][] getFirstPageData() {

		Object data[][] = ReadExcelfile.getTestData(sheetName1);
		return data;
	}

	@Test(priority = 0, dataProvider = "getFirstPageData", groups = "Regression")
	public void fillingFormUsingValidDetails(String Fname, String Lname, String JFunc, String JTitle, String Email,
			String Instiname, String Institype, String disp, String country) {

		parentWindow = driver.getWindowHandle();
		fillingForm.clickonForCampus();
		Set<String> handles = driver.getWindowHandles();
		Iterator<String> itr = handles.iterator();
		while (itr.hasNext()) {

			String childWindow1 = itr.next();
			if (!childWindow1.contentEquals(parentWindow)) {
				driver.switchTo().window(childWindow1);
				fillingForm.clickGetStarted();
				try {
					
					Thread.sleep(1000);
					fillingForm.execelAllValidDetails(Fname, Lname, JFunc, JTitle, Email, Instiname, Institype, disp,
							country);

				} catch (Exception e) {
					e.printStackTrace();
				}
				driver.close();
			}
			driver.switchTo().window(parentWindow);
		}
	}


	@AfterClass
	public void tearDown() {

		driver.quit();
	}
}


