package pages;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.DriverSetup;

public class ExtractWebDevelopmentCourses extends DriverSetup{

	Logger log = Logger.getLogger(ExtractWebDevelopmentCourses.class);
	// Page Objects
	@FindBy(xpath = "/html[1]/body[1]/div[3]/div[1]/div[1]/main[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[1]/div[1]/div[1]/a[1]/div[1]/div[2]/h2[1]")
	public WebElement firstCourseName;

	@FindBy(xpath = "//*[@id=\"main\"]/div/div/div[1]/div/div[2]/div/div/div/div/ul/li[1]/div/div/a/div/div[2]/div[3]/div[1]/div[1]/div/span[2]/span")
	WebElement firstCourseRating;

	@FindBy(xpath = "/html/body/div[3]/div/div/main/div/div[2]/div/div/div/div[2]/div/div/div[5]/div[2]/div/span")
	public WebElement firstCourseHours;

	@FindBy(xpath = "//*[@id=\"main\"]/div/div/div[1]/div/div[2]/div/div/div/div/ul/li[2]/div/div/a/div/div[2]/h2")
	public WebElement secondCourseName;

	@FindBy(xpath = "//*[@id=\"main\"]/div/div/div[1]/div/div[2]/div/div/div/div/ul/li[2]/div/div/a/div/div[2]/div[3]/div[1]/div[1]/div/span[2]/span")
	WebElement secondCourseRating;

	@FindBy(xpath = "//body/div[@id='rendered-content']/div[1]/div[1]/main[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[5]/div[2]/div/span")
	public WebElement secondCourseHours;

	By name = By.xpath("//*[@id=\"main\"]/div/div/div[1]/div/div[2]/div/div/div/div/ul/li/div/div/a/div/div[2]/h2");
	By rating = By.className("ratings-text");

	List <WebElement> names = driver.findElements(name);
	List <WebElement> ratings = driver.findElements(rating);

	//Initializing the Page Object
	public ExtractWebDevelopmentCourses() {

		PageFactory.initElements(driver, this);
	}

	public void findCourses()
	{
		//System.out.println("The courses and their ratings are: ");

		for (int j = 0; j < 2; ++j) {
			System.out.println("\nCourse name:"+names.get(j).getText() + "\nRatings: " + ratings.get(j).getText());
			WebDriverWait wait = new WebDriverWait(driver, 20);
			String parentWindow = driver.getWindowHandle();
			wait.until(ExpectedConditions.elementToBeClickable(names.get(j)));
			names.get(j).click();
			Set<String> handles1 = driver.getWindowHandles();
			Iterator<String> itr1 = handles1.iterator();
			while(itr1.hasNext()) {

				String childWindow1 = itr1.next();
				if (!childWindow1.contentEquals(parentWindow)) {
					driver.switchTo().window(childWindow1);
					log.info("Switched to the course page to get the details");
					if(j==0)
					{	
						log.info("FIRST COURSE");
						String fhours = firstCourseHours.getText();
						System.out.println("Total learning hours of first course: "+fhours);
					}
					else
					{
						log.info("SECOND COURSE");
						String fhours = secondCourseHours.getText();
						System.out.println("Total learning hours of second course: "+fhours);
					}
					driver.close();
				}
				driver.switchTo().window(parentWindow);
				log.info("Switched Back to Parent Window");
			}
		}
	}

	// Returns the name is displayed or not
	public boolean CourseName() {

		boolean flag = false;
		flag=firstCourseName.isDisplayed();
		if(flag==true) {
			log.info("Course Name is displayed");
		}
		else {log.info("Course name is not displayed");}
		return flag;
	}

	// Returns the ratings of the first course is displayed
	public boolean CourseRating1() {
		boolean flag = false;
		flag=firstCourseRating.isDisplayed();
		return flag;

	}

	// Returns the name is displayed or not
	public boolean CourseName2() {

		boolean flag = false;
		flag=secondCourseName.isDisplayed();
		return flag;
	}

	// Returns the ratings of the second course is displayed
	public boolean CourseRating2() {

		boolean flag = false;
		flag=secondCourseRating.isDisplayed();
		return flag;
	}

	// Returns the total hours of the first course is displayed
	public boolean CourseHours1() {

		boolean flag = false;
		String parentWindow = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(firstCourseName));
		firstCourseName.click();
		Set<String> handles1 = driver.getWindowHandles();
		Iterator<String> itr1 = handles1.iterator();
		while(itr1.hasNext()) {

			String childWindow1 = itr1.next();
			if (!childWindow1.contentEquals(parentWindow)) {
				driver.switchTo().window(childWindow1);
				flag=firstCourseHours.isDisplayed();
			}
			driver.switchTo().window(parentWindow);
		}
		return flag;
	}

	// Returns the total hours of the second course is displayed
	public boolean CourseHours2() {

		boolean flag = false;
		String parentWindow = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(secondCourseName));
		secondCourseName.click();
		Set<String> handles1 = driver.getWindowHandles();
		Iterator<String> itr1 = handles1.iterator();
		while(itr1.hasNext()) {

			String childWindow1 = itr1.next();
			if (!childWindow1.contentEquals(parentWindow)) {
				driver.switchTo().window(childWindow1);
				flag=secondCourseHours.isDisplayed();
			}
			driver.switchTo().window(parentWindow);
		}

		return flag;
	}


}
