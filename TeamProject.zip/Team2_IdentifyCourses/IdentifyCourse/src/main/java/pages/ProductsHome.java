package pages;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.DriverSetup;
import utilities.ScreenShots;

public class ProductsHome extends DriverSetup {
	Logger log = Logger.getLogger(ProductsHome.class);
	@FindBy(xpath = "//div[@class = 'menu-menu-1-container']//li[2]")
	WebElement Products;

	@FindBy(xpath = "//a[@target='_blank'][contains(text(),'For Campus')]")
	WebElement ForCampus;

	@FindBy(xpath = "//*[@id=\"menu-item-9140\"]/ul")
	WebElement Dropdown;

	ScreenShots s=new ScreenShots(driver);
	Actions action;

	// Initializing the pageobjects
	public ProductsHome() {

		log.info("Page Object initialised");
		PageFactory.initElements(driver, this);
	}
    
	//Check for Products 
	public boolean checkForProducts(){
		log.info("Product Menu is checking");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return Products.isDisplayed();

	}
	
	//Check for dropdown under products
	public boolean checkDropdown(){
		log.info("Submenus of Product is checking");
		action = new Actions(driver);
		action.moveToElement(Products);
		action.build().perform();
		return Dropdown.isEnabled();
	}

	//Check for ForCampus 
	public boolean checkForCampus(){
		log.info("Checking for option 'For Campus'");
		s.captureScreenShot();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return ForCampus.isDisplayed();
	}


	// It will select the For Campus option from products
	public void clickonForCampus() {
		log.info("Clicking 'For Campus'");
		ForCampus.click();

	}
	
    public FillingForm navigateToFillingForm() {
		log.info("Filling 'Ready to transform campus?' form");
    	/*Actions action = new Actions(driver);
		action.moveToElement(Products);
		action.build().perform();
		ForCampus.click();*/
		return new FillingForm();
	}
}

